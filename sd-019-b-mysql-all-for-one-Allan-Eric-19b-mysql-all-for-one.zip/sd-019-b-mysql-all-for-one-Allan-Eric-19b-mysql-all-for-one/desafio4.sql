# conte quantos registros existem na coluna product_name da tabela products
SELECT COUNT(product_name) FROM northwind.products;