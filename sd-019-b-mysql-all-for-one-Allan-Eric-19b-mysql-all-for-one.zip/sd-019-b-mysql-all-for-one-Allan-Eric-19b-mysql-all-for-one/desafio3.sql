# "3 - Escreva uma query que exiba os valores da coluna que contém a primary key da tabela 'products'"
SELECT products.id FROM products;