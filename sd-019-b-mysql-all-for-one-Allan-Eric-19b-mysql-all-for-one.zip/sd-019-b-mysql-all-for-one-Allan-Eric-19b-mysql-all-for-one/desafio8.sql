# Faça uma consulta que retorne três colunas, respectivamente, com os nomes A: 5 + 6, Trybe: de, eh: 2 + 8.
SELECT (5+6) as 'A', 'de' as 'Trybe', (2+8) as 'eh';
