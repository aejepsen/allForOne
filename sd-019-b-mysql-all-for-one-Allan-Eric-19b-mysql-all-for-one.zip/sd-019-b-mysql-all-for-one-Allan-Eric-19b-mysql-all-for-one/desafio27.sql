# Delete todos os dados da tabela `order_details`

delete from order_details;