const challengeResult17 = [
  { id: 90, supplier_id: 1 },
  { id: 96, supplier_id: 1 },
  { id: 99, supplier_id: 1 },
  { id: 101, supplier_id: 1 },
  { id: 102, supplier_id: 1 },
  { id: 107, supplier_id: 1 },
  { id: 110, supplier_id: 1 },
  { id: 111, supplier_id: 1 },
  { id: 91, supplier_id: 3 },
  { id: 93, supplier_id: 5 },
  { id: 105, supplier_id: 5 },
  { id: 148, supplier_id: 5 },
  { id: 147, supplier_id: 7 }
];

module.exports = challengeResult17;
