const challengeResult14 = [
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 1 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 2 },
  { supplier_id: 3 }

];

module.exports = challengeResult14;
