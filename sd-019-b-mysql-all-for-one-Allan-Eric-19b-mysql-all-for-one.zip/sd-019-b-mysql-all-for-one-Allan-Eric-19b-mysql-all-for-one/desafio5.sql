# Monte uma query que exiba os dados da tabela products a partir do quarto 4  registro até o  13 décimo terceiro
SELECT * FROM products LIMIT 3,10;